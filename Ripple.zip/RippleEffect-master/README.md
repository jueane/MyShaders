Water surface ripple effect for Unity
-------------------------------------

![screenshot](http://keijiro.github.io/RippleEffect/screenshot.png)

https://vine.co/v/MrF1utblYLM

This is an image effect that distorts the rendered image with ripples on a water surface.

### License

You can use the scripts and the shaders in this project as you like.
